export { default as Main } from './main';
export { default as Menu } from './menu';
export { default as Loading } from './loading';